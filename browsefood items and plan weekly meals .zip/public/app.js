// ---------- Current user (set by the login screen) ----------
let CURRENT_USER = null; // { id, full_name }

// ---------- small helpers ----------

// Escape user/data-driven text before dropping it into innerHTML, so a donor
// typing "<script>" into a listing name can't inject markup into the page.
function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

const networkErrorBox = document.getElementById("network-error");

// Wraps fetch + JSON parsing so every call site gets the same handling for
// network failures (server down, offline, etc.) instead of a silent crash.
async function apiCall(url, options) {
  let res;
  try {
    res = await fetch(url, options);
  } catch (err) {
    networkErrorBox.textContent = "Couldn't reach the server. Is it still running?";
    networkErrorBox.classList.remove("hidden");
    throw err;
  }
  networkErrorBox.classList.add("hidden");
  let data = {};
  try {
    data = await res.json();
  } catch (_) {
    // no JSON body (e.g. a 204) - that's fine
  }
  return { ok: res.ok, status: res.status, data };
}

// ---------- Tabs ----------
document.querySelectorAll(".tab").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".panel").forEach((p) => p.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(btn.dataset.tab).classList.add("active");
    if (btn.dataset.tab === "mylistings") loadMyListings();
  });
});

// ============================================================
// UC3 - Browse Food Items
// ============================================================

async function loadDonations() {
  const category = document.getElementById("f-category").value;
  const location = document.getElementById("f-location").value;
  const storageType = document.getElementById("f-storage").value;
  const expiryDate = document.getElementById("f-expiry").value;
  const search = document.getElementById("f-search").value;
  const params = new URLSearchParams();
  if (category) params.set("category", category);
  if (location) params.set("location", location);
  if (storageType) params.set("storageType", storageType);
  if (expiryDate) params.set("expiryDate", expiryDate);
  if (search) params.set("search", search);

  const { ok, data } = await apiCall("/api/donations?" + params.toString());
  if (!ok) return;

  const list = document.getElementById("donation-list");
  const empty = document.getElementById("donation-empty");
  list.innerHTML = "";

  if (!data.items.length) {
    empty.textContent = data.message || "No donations found.";
    empty.classList.remove("hidden");
    return;
  }
  empty.classList.add("hidden");

  data.items.forEach((d) => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <h3>${esc(d.item_name)}</h3>
      <div class="meta">${esc(d.quantity)} ${esc(d.unit)} &middot; ${esc(d.category)}</div>
      <div class="meta">📍 ${esc(d.pickup_location)} &middot; ${esc(d.storage_type || "—")}</div>
      <div class="meta">Expires ${esc(d.expiry_date)}</div>
      <span class="badge">${esc(d.status)}</span>
    `;
    card.addEventListener("click", () => openDetail(d.id));
    list.appendChild(card);
  });
}

async function openDetail(id) {
  const { ok, data: d } = await apiCall(`/api/donations/${id}`);
  if (!ok) return;
  const box = document.getElementById("detail-box");

  const isOwnListing = d.donor_id === CURRENT_USER.id;
  box.innerHTML = `
    <h3>${esc(d.item_name)}</h3>
    <p><strong>Quantity:</strong> ${esc(d.quantity)} ${esc(d.unit)}</p>
    <p><strong>Expiry date:</strong> ${esc(d.expiry_date)}</p>
    <p><strong>Storage type:</strong> ${esc(d.storage_type || "—")}</p>
    <p><strong>Pickup location:</strong> ${esc(d.pickup_location)}</p>
    <p><strong>Contact method:</strong> ${esc(d.contact_method)}</p>
    <p><strong>Notes:</strong> ${esc(d.availability_info || "—")}</p>
    <p><span class="badge">${esc(d.status)}</span></p>
    ${isOwnListing ? `<p class="meta">This is your own listing — view it under "My Listings" to confirm claims.</p>` : ""}
    <div id="claim-msg"></div>
    <div class="close-row">
      ${d.status === "active" && !isOwnListing ? `<button class="btn" id="btn-claim">Request Donation</button>` : ""}
      <button class="btn ghost" id="btn-close">Close</button>
    </div>
  `;
  document.getElementById("detail-modal").classList.remove("hidden");
  document.getElementById("btn-close").addEventListener("click", closeDetail);

  const claimBtn = document.getElementById("btn-claim");
  if (claimBtn) {
    claimBtn.addEventListener("click", async () => {
      const { ok: claimOk, data: result } = await apiCall(`/api/donations/${id}/claim`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ claimerId: CURRENT_USER.id }),
      });
      const msg = document.getElementById("claim-msg");
      if (!claimOk) {
        msg.innerHTML = `<p class="error">${esc(result.error)}</p>`;
      } else {
        msg.innerHTML = `<p style="color:#2f7a52;font-weight:600;">${esc(result.message)}</p>`;
        claimBtn.disabled = true;
        loadDonations();
      }
    });
  }
}
function closeDetail() { document.getElementById("detail-modal").classList.add("hidden"); }

document.getElementById("btn-filter").addEventListener("click", loadDonations);
document.getElementById("f-search").addEventListener("keydown", (e) => {
  if (e.key === "Enter") loadDonations();
});
document.getElementById("btn-reset").addEventListener("click", () => {
  document.getElementById("f-category").value = "";
  document.getElementById("f-location").value = "";
  document.getElementById("f-storage").value = "";
  document.getElementById("f-expiry").value = "";
  document.getElementById("f-search").value = "";
  loadDonations();
});

// ---------- Add Item (donor posts a new donation listing) ----------

const addItemModal = document.getElementById("add-item-modal");
const addItemForm = document.getElementById("add-item-form");
const addItemError = document.getElementById("add-item-error");

function openAddItemModal() {
  addItemError.classList.add("hidden");
  addItemForm.reset();
  addItemModal.classList.remove("hidden");
}
function closeAddItemModal() { addItemModal.classList.add("hidden"); }

document.getElementById("btn-add-item").addEventListener("click", openAddItemModal);
document.getElementById("btn-add-item-close").addEventListener("click", closeAddItemModal);

addItemForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const payload = {
    donorId: CURRENT_USER.id,
    itemName: document.getElementById("ai-name").value.trim(),
    quantity: Number(document.getElementById("ai-qty").value),
    unit: document.getElementById("ai-unit").value.trim(),
    category: document.getElementById("ai-category").value,
    expiryDate: document.getElementById("ai-expiry").value,
    storageType: document.getElementById("ai-storage").value,
    pickupLocation: document.getElementById("ai-location").value.trim(),
    contactMethod: document.getElementById("ai-contact").value.trim(),
    availabilityInfo: document.getElementById("ai-notes").value.trim(),
  };

  const { ok, data: result } = await apiCall("/api/donations", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!ok) {
    addItemError.textContent = result.error;
    addItemError.classList.remove("hidden");
    return;
  }
  closeAddItemModal();
  loadDonations();
});

// ============================================================
// Donor view - My Listings & confirming claims (TC06 in the UI)
// ============================================================

async function loadMyListings() {
  const donorId = CURRENT_USER.id;
  const { ok, data } = await apiCall(`/api/my-donations?donorId=${donorId}`);
  if (!ok) return;

  const list = document.getElementById("mylistings-list");
  const empty = document.getElementById("mylistings-empty");
  list.innerHTML = "";

  if (!data.listings.length) {
    empty.textContent = "You don't have any listings yet.";
    empty.classList.remove("hidden");
    return;
  }
  empty.classList.add("hidden");

  data.listings.forEach((d) => {
    const pendingClaims = d.claims.filter((c) => c.status === "pending");
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <h3>${esc(d.item_name)}</h3>
      <div class="meta">${esc(d.quantity)} ${esc(d.unit)} &middot; ${esc(d.category)}</div>
      <span class="badge">${esc(d.status)}</span>
      ${pendingClaims.map((c) => `
        <div class="meta" style="margin-top:8px;">
          Claim request from ${esc(c.claimer_name)}
          <button class="btn small confirm-claim-btn" data-claim-id="${c.id}" style="margin-left:6px;">Confirm</button>
        </div>
      `).join("")}
      ${!pendingClaims.length && d.claims.length ? `<div class="meta">All claims on this listing are resolved.</div>` : ""}
    `;
    card.querySelectorAll(".confirm-claim-btn").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.stopPropagation();
        const { ok: confirmOk, data: result } = await apiCall(`/api/claims/${btn.dataset.claimId}/confirm`, { method: "PUT" });
        if (!confirmOk) { alert(result.error); return; }
        loadMyListings();
        loadNotifications();
      });
    });
    list.appendChild(card);
  });
}

// ============================================================
// UC6 - Plan Weekly Meals
// ============================================================

async function loadInventory() {
  const { ok, data } = await apiCall(`/api/inventory?userId=${CURRENT_USER.id}`);
  if (!ok) return;

  const list = document.getElementById("inventory-list");
  list.innerHTML = "";
  data.items.forEach((i) => {
    const soon = daysUntil(i.expiry_date) <= 1;
    const li = document.createElement("li");
    li.innerHTML = `<span>${esc(i.item_name)} — ${esc(i.quantity)}${esc(i.unit)} ${i.reserved_quantity ? `(reserved: ${esc(i.reserved_quantity)}${esc(i.unit)})` : ""}</span>
      <span class="${soon ? "expiring" : ""}">${soon ? "expires soon" : esc(i.expiry_date)}</span>`;
    list.appendChild(li);
  });

  const itemsBox = document.getElementById("meal-items");
  itemsBox.innerHTML = "";
  data.items.forEach((i) => {
    const available = i.quantity - (i.reserved_quantity || 0);
    itemsBox.innerHTML += `
      <label><input type="checkbox" value="${i.id}" data-name="${esc(i.item_name)}" ${available <= 0 ? "disabled" : ""} /> ${esc(i.item_name)}${available <= 0 ? " (none left)" : ""}</label>`;
  });
}

function daysUntil(dateStr) {
  return Math.round((new Date(dateStr) - new Date()) / 86400000);
}

// ---------- Add Item to Your Inventory (from the Plan Weekly Meals page) ----------

const addInventoryModal = document.getElementById("add-inventory-modal");
const addInventoryForm = document.getElementById("add-inventory-form");
const addInventoryError = document.getElementById("add-inventory-error");

function openAddInventoryModal() {
  addInventoryError.classList.add("hidden");
  addInventoryForm.reset();
  addInventoryModal.classList.remove("hidden");
}
function closeAddInventoryModal() { addInventoryModal.classList.add("hidden"); }

// Both the "Your Inventory" header and the "Recipe Suggestions" header open
// the same modal - wherever you spot the missing ingredient, you can add it.
document.getElementById("btn-add-inventory").addEventListener("click", openAddInventoryModal);
document.getElementById("btn-add-inventory-2").addEventListener("click", openAddInventoryModal);
document.getElementById("btn-add-inventory-close").addEventListener("click", closeAddInventoryModal);

addInventoryForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const payload = {
    userId: CURRENT_USER.id,
    itemName: document.getElementById("inv-name").value.trim(),
    quantity: Number(document.getElementById("inv-qty").value),
    unit: document.getElementById("inv-unit").value.trim(),
    category: document.getElementById("inv-category").value,
    expiryDate: document.getElementById("inv-expiry").value,
  };

  const { ok, data: result } = await apiCall("/api/inventory", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!ok) {
    addInventoryError.textContent = result.error;
    addInventoryError.classList.remove("hidden");
    return;
  }
  closeAddInventoryModal();
  loadInventory(); // refreshes the list + the meal-item checkboxes
  loadRecipes();   // the new item might complete a recipe match
});

async function loadMealPlans() {
  const { ok, data } = await apiCall(`/api/meal-plans?userId=${CURRENT_USER.id}`);
  if (!ok) return;
  const body = document.getElementById("calendar-body");
  const slots = ["breakfast", "lunch", "dinner", "snack"];
  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

  body.innerHTML = "";
  slots.forEach((slot) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `<td><strong>${slot}</strong></td>` + days.map(() => "<td></td>").join("");
    body.appendChild(tr);
  });

  data.plans.forEach((p) => {
    const rowIdx = slots.indexOf(p.meal_slot);
    // day is stored as a plain label in meal_date for this in-memory demo
    const colIdx = days.indexOf(p.meal_date);
    if (rowIdx === -1 || colIdx === -1) return;
    const cell = body.rows[rowIdx].cells[colIdx + 1];
    const chip = document.createElement("span");
    chip.className = "meal-chip";
    chip.innerHTML = `${esc(p.description)} <span class="meal-chip-x" title="Remove">×</span>`;
    chip.querySelector(".meal-chip-x").addEventListener("click", async () => {
      const { ok: delOk, data: result } = await apiCall(`/api/meal-plans/${p.id}`, { method: "DELETE" });
      if (!delOk) { alert(result.error); return; }
      loadMealPlans();
      loadInventory();
    });
    cell.appendChild(chip);
  });
}

document.getElementById("add-meal-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const day = document.getElementById("meal-day").value;
  const slot = document.getElementById("meal-slot").value;
  const checked = [...document.querySelectorAll("#meal-items input:checked")];
  const errorBox = document.getElementById("meal-error");

  const items = checked.map((c) => ({ inventoryItemId: Number(c.value), itemName: c.dataset.name, quantity: 1 }));

  const { ok, data: result } = await apiCall("/api/meal-plans", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId: CURRENT_USER.id, mealDate: day, mealSlot: slot, items }),
  });

  if (!ok) {
    errorBox.textContent = result.error;
    errorBox.classList.remove("hidden");
    return;
  }
  errorBox.classList.add("hidden");
  checked.forEach((c) => (c.checked = false));
  document.getElementById("meal-day").value = "";
  document.getElementById("meal-slot").value = "";
  loadMealPlans();
  loadInventory();
});

const DAY_OPTIONS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const SLOT_OPTIONS = ["breakfast", "lunch", "dinner", "snack"];

async function loadRecipes() {
  const { ok, data } = await apiCall(`/api/recipes/suggestions?userId=${CURRENT_USER.id}`);
  if (!ok) return;
  const box = document.getElementById("recipe-list");
  box.innerHTML = "";

  if (!data.recipes.length) {
    box.innerHTML = `<div class="empty">${esc(data.message)}</div>`;
    return;
  }

  data.recipes.forEach((r) => {
    const card = document.createElement("div");
    card.className = "recipe-card";
    card.innerHTML = `
      <h4>${esc(r.name)}</h4>
      <p>Uses: ${esc(r.ingredients.join(", "))}</p>
      <div class="recipe-day-slot">
        <select class="recipe-day">
          <option value="">Day…</option>
          ${DAY_OPTIONS.map((d) => `<option>${d}</option>`).join("")}
        </select>
        <select class="recipe-slot">
          <option value="">Slot…</option>
          ${SLOT_OPTIONS.map((s) => `<option>${s}</option>`).join("")}
        </select>
      </div>
      <div class="recipe-error error hidden"></div>
      <button class="btn small" data-recipe="${esc(r.name)}">Add to Plan</button>
    `;
    const errorBox = card.querySelector(".recipe-error");
    card.querySelector("button").addEventListener("click", async () => {
      const day = card.querySelector(".recipe-day").value;
      const slot = card.querySelector(".recipe-slot").value;
      if (!day || !slot) {
        errorBox.textContent = "Pick a day and a slot for this recipe first.";
        errorBox.classList.remove("hidden");
        return;
      }
      errorBox.classList.add("hidden");
      const { ok: addOk, data: result } = await apiCall("/api/meal-plans/from-recipe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: CURRENT_USER.id, recipeName: r.name, mealDate: day, mealSlot: slot }),
      });
      if (addOk) {
        loadMealPlans();
        loadInventory();
      } else {
        errorBox.textContent = result.error;
        errorBox.classList.remove("hidden");
      }
    });
    box.appendChild(card);
  });
}

// ============================================================
// Notifications ("receive a notification with pickup details")
// ============================================================

async function loadNotifications() {
  const { ok, data } = await apiCall(`/api/notifications?userId=${CURRENT_USER.id}`);
  if (!ok) return;

  const countEl = document.getElementById("notif-count");
  if (data.unreadCount > 0) {
    countEl.textContent = data.unreadCount;
    countEl.classList.remove("hidden");
  } else {
    countEl.classList.add("hidden");
  }

  const panel = document.getElementById("notif-panel");
  if (!data.notifications.length) {
    panel.innerHTML = `<div class="notif-empty">No notifications yet.</div>`;
    return;
  }
  panel.innerHTML = data.notifications
    .map((n) => `
      <div class="notif-item ${n.is_read ? "" : "unread"}">
        <div>${esc(n.message)}</div>
        <div class="notif-time">${new Date(n.created_at).toLocaleString()}</div>
      </div>
    `)
    .join("");
}

const notifBell = document.getElementById("notif-bell");
const notifPanel = document.getElementById("notif-panel");
notifBell.addEventListener("click", async (e) => {
  e.stopPropagation();
  notifPanel.classList.toggle("hidden");
  if (!notifPanel.classList.contains("hidden")) {
    await apiCall("/api/notifications/read-all", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: CURRENT_USER.id }),
    });
    loadNotifications();
  }
});
document.addEventListener("click", (e) => {
  if (!notifPanel.contains(e.target) && e.target !== notifBell) {
    notifPanel.classList.add("hidden");
  }
});

// ============================================================
// Login
// ============================================================

const loginScreen = document.getElementById("login-screen");
const appShell = document.getElementById("app-shell");
const loginForm = document.getElementById("login-form");
const loginError = document.getElementById("login-error");

async function populateLoginOptions() {
  const { ok, data } = await apiCall("/api/users");
  if (!ok) return;
  const select = document.getElementById("login-user");
  select.innerHTML = data.users.map((u) => `<option value="${u.id}">${esc(u.full_name)}</option>`).join("");
}

function startApp() {
  loginScreen.classList.add("hidden");
  appShell.classList.remove("hidden");
  document.getElementById("current-user-name").textContent = CURRENT_USER.full_name;
  loadDonations();
  loadMyListings();
  loadInventory();
  loadMealPlans();
  loadRecipes();
  loadNotifications();
}

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const userId = Number(document.getElementById("login-user").value);
  const password = document.getElementById("login-password").value;
  const { ok, data } = await apiCall("/api/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, password }),
  });
  if (!ok) {
    loginError.textContent = data.error;
    loginError.classList.remove("hidden");
    return;
  }
  loginError.classList.add("hidden");
  CURRENT_USER = data.user;
  // sessionStorage (not localStorage) so the token is cleared when the tab
  // is closed, and it's a random token rather than the password itself.
  sessionStorage.setItem("freshguard_token", data.token);
  startApp();
});

document.getElementById("btn-logout").addEventListener("click", async () => {
  const token = sessionStorage.getItem("freshguard_token");
  sessionStorage.removeItem("freshguard_token");
  CURRENT_USER = null;
  loginForm.reset();
  appShell.classList.add("hidden");
  loginScreen.classList.remove("hidden");
  if (token) {
    await apiCall("/api/logout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token }),
    });
  }
});

// ---------- init ----------
// If a session token from an earlier login is still around, resume that
// session automatically so a page refresh doesn't send you back to the
// login screen. The password itself is never stored, only this token.
(async function init() {
  await populateLoginOptions();

  const token = sessionStorage.getItem("freshguard_token");
  if (token) {
    const { ok, data } = await apiCall(`/api/session?token=${encodeURIComponent(token)}`);
    if (ok) {
      CURRENT_USER = data.user;
      startApp();
    } else {
      sessionStorage.removeItem("freshguard_token"); // stale/expired - clear it
    }
  }
})();
