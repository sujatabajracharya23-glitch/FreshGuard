/**
 * Automated test suite for the FreshGuard Iteration 1 API.
 *
 * This runs every documented test case (TC01-TC14 from
 * Assignment2_Iteration1_Task1) against the *actual* running Express app,
 * plus a few extra cases covering the fixes made in this pass. It's the
 * code-level proof to go with your written Testing Template.
 *
 * Run with:  npm test
 */
const test = require("node:test");
const assert = require("node:assert/strict");
const http = require("node:http");

const app = require("../server");
const db = require("../data");

let server;
let baseUrl;

test.before(async () => {
  server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, resolve));
  baseUrl = `http://localhost:${server.address().port}`;
});

test.after(async () => {
  await new Promise((resolve) => server.close(resolve));
});

// Give each test file a clean, documented starting state.
test.beforeEach(() => db.resetData());

async function api(path, options) {
  const res = await fetch(baseUrl + path, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options && options.headers) },
  });
  let body = null;
  try { body = await res.json(); } catch (_) { /* no body */ }
  return { status: res.status, ok: res.ok, body };
}

// ---------- UC3: Browse Food Items ----------

test("TC01 - view all active listings", async () => {
  const { status, body } = await api("/api/donations");
  assert.equal(status, 200);
  // 4 seeded, 1 already claimed -> 3 active
  assert.equal(body.items.length, 3);
  assert.ok(body.items.every((d) => d.status === "active"));
});

test("TC02 - category filter returns only matching category", async () => {
  const { body } = await api("/api/donations?category=Dairy");
  assert.equal(body.items.length, 1);
  assert.equal(body.items[0].item_name, "Milk");
});

test("TC03 - no-match filter combination -> empty state, not an error", async () => {
  const { status, body } = await api("/api/donations?category=Frozen&location=Unknown%20Area");
  assert.equal(status, 200);
  assert.equal(body.items.length, 0);
  assert.match(body.message, /no donations match/i);
});

test("TC04 - view listing detail", async () => {
  const { status, body } = await api("/api/donations/2");
  assert.equal(status, 200);
  assert.equal(body.item_name, "White Bread");
});

test("TC05 - claim an active listing", async () => {
  const { status, body } = await api("/api/donations/1/claim", {
    method: "POST",
    body: JSON.stringify({ claimerId: 1 }),
  });
  assert.equal(status, 201);
  assert.equal(body.claim.status, "pending");
});

test("TC06 - donor confirms claim, claimer gets notified with pickup details", async () => {
  const claimRes = await api("/api/donations/1/claim", { method: "POST", body: JSON.stringify({ claimerId: 1 }) });
  const claimId = claimRes.body.claim.id;

  const { status, body } = await api(`/api/claims/${claimId}/confirm`, { method: "PUT" });
  assert.equal(status, 200);
  assert.equal(body.donation.status, "claimed");
  assert.match(body.message, /confirmed/i);
});

test("TC07 - block claiming an already-claimed listing", async () => {
  // donation 4 (Chicken Fillet) is seeded as already claimed
  const { status, body } = await api("/api/donations/4/claim", {
    method: "POST",
    body: JSON.stringify({ claimerId: 1 }),
  });
  assert.equal(status, 409);
  assert.match(body.error, /already been claimed/i);
});

// ---------- UC6: Plan Weekly Meals ----------

test("TC08 - calendar + inventory load", async () => {
  const inv = await api("/api/inventory?userId=1");
  const plans = await api("/api/meal-plans?userId=1");
  assert.equal(inv.status, 200);
  assert.ok(inv.body.items.length > 0);
  assert.equal(plans.status, 200);
  assert.deepEqual(plans.body.plans, []);
});

test("TC09 - add a meal reserves the inventory used", async () => {
  const { status, body } = await api("/api/meal-plans", {
    method: "POST",
    body: JSON.stringify({
      userId: 1, mealDate: "Monday", mealSlot: "dinner",
      items: [{ inventoryItemId: 1, itemName: "Chicken", quantity: 200 }],
    }),
  });
  assert.equal(status, 201);
  assert.equal(body.items[0].reserved_quantity, 200);

  const inv = await api("/api/inventory?userId=1");
  const chicken = inv.body.items.find((i) => i.item_name === "Chicken");
  assert.equal(chicken.reserved_quantity, 200);
});

test("TC10 - validation error when day/slot/items missing", async () => {
  const { status, body } = await api("/api/meal-plans", {
    method: "POST",
    body: JSON.stringify({ userId: 1, items: [] }),
  });
  assert.equal(status, 422);
  assert.match(body.error, /day.*slot.*item/i);

  // nothing should have been saved
  const plans = await api("/api/meal-plans?userId=1");
  assert.equal(plans.body.plans.length, 0);
});

test("TC11 - recipe suggestions match current inventory", async () => {
  const { status, body } = await api("/api/recipes/suggestions?userId=1");
  assert.equal(status, 200);
  assert.ok(body.recipes.some((r) => r.name === "Egg Fried Rice"));
});

test("TC12 - add a suggested recipe straight to the plan", async () => {
  const { status, body } = await api("/api/meal-plans/from-recipe", {
    method: "POST",
    body: JSON.stringify({ userId: 1, recipeName: "Egg Fried Rice", mealDate: "Tuesday", mealSlot: "lunch" }),
  });
  assert.equal(status, 201);
  assert.equal(body.plan.description, "Egg Fried Rice");
  assert.ok(body.items.length > 0);
});

test("TC13 - no matching recipes -> friendly message", async () => {
  const { status, body } = await api("/api/recipes/suggestions?userId=1&onlyItemNames=Rice");
  assert.equal(status, 200);
  assert.equal(body.recipes.length, 0);
  assert.match(body.message, /no matching recipes/i);
});

test("TC14 - suggestions prioritise the soonest-expiring ingredient", async () => {
  const { body } = await api("/api/recipes/suggestions?userId=1");
  // Spinach (expires in 1 day) is only used by Veggie Pasta, so it should
  // be ranked ahead of recipes whose ingredients expire further out.
  const names = body.recipes.map((r) => r.name);
  assert.equal(names[0], "Veggie Pasta");
});

// ---------- Fixes added in this pass ----------

test("a donor cannot claim their own donation", async () => {
  // donation 1 belongs to donor_id 2
  const { status, body } = await api("/api/donations/1/claim", {
    method: "POST",
    body: JSON.stringify({ claimerId: 2 }),
  });
  assert.equal(status, 400);
  assert.match(body.error, /can't claim your own/i);
});

test("reserving more than is in stock is rejected, and nothing is partially saved", async () => {
  const { status, body } = await api("/api/meal-plans", {
    method: "POST",
    body: JSON.stringify({
      userId: 1, mealDate: "Wednesday", mealSlot: "lunch",
      items: [{ inventoryItemId: 4, itemName: "Onion", quantity: 99 }],
    }),
  });
  assert.equal(status, 422);
  assert.match(body.error, /not enough/i);

  const plans = await api("/api/meal-plans?userId=1");
  assert.equal(plans.body.plans.length, 0);
});

test("removing a planned meal releases its reserved inventory", async () => {
  const add = await api("/api/meal-plans", {
    method: "POST",
    body: JSON.stringify({
      userId: 1, mealDate: "Thursday", mealSlot: "breakfast",
      items: [{ inventoryItemId: 3, itemName: "Eggs", quantity: 4 }],
    }),
  });
  const planId = add.body.plan.id;

  let inv = await api("/api/inventory?userId=1");
  assert.equal(inv.body.items.find((i) => i.item_name === "Eggs").reserved_quantity, 4);

  const del = await api(`/api/meal-plans/${planId}`, { method: "DELETE" });
  assert.equal(del.status, 200);

  inv = await api("/api/inventory?userId=1");
  assert.equal(inv.body.items.find((i) => i.item_name === "Eggs").reserved_quantity, 0);
});

test("a donor can see and confirm a pending claim via /api/my-donations", async () => {
  await api("/api/donations/1/claim", { method: "POST", body: JSON.stringify({ claimerId: 1 }) });

  const mine = await api("/api/my-donations?donorId=2");
  const listing = mine.body.listings.find((d) => d.id === 1);
  assert.equal(listing.claims.length, 1);
  assert.equal(listing.claims[0].status, "pending");
});

test("invalid donation id returns 400, not a crash", async () => {
  const { status } = await api("/api/donations/not-a-number");
  assert.equal(status, 400);
});

// ---------- Browse Food Items: add item + search (this pass) ----------

test("a donor can post a new donation listing, which then shows up when browsing", async () => {
  const { status, body } = await api("/api/donations", {
    method: "POST",
    body: JSON.stringify({
      donorId: 2, itemName: "Yogurt", quantity: 4, unit: "cups",
      category: "Dairy", expiryDate: "2099-01-01",
      pickupLocation: "Block D, Kathmandu", contactMethod: "WhatsApp: +977-91XXXXXXXX",
    }),
  });
  assert.equal(status, 201);
  assert.equal(body.donation.status, "active");

  const list = await api("/api/donations?category=Dairy");
  assert.ok(list.body.items.some((d) => d.item_name === "Yogurt"));
});

test("posting a new listing without required fields is rejected", async () => {
  const { status, body } = await api("/api/donations", {
    method: "POST",
    body: JSON.stringify({ itemName: "Mystery Item" }),
  });
  assert.equal(status, 422);
  assert.match(body.error, /required/i);
});

test("search matches item name, category, or notes", async () => {
  const byName = await api("/api/donations?search=apple");
  assert.ok(byName.body.items.some((d) => d.item_name === "Apples (Fuji)"));

  const byNotes = await api("/api/donations?search=unopened");
  assert.ok(byNotes.body.items.some((d) => d.item_name === "Milk"));

  const noMatch = await api("/api/donations?search=doesnotexist123");
  assert.equal(noMatch.body.items.length, 0);
});

// ---------- Storage type filter ----------

test("storage type filter returns only matching listings", async () => {
  const { status, body } = await api("/api/donations?storageType=Refrigerated");
  assert.equal(status, 200);
  assert.equal(body.items.length, 1);
  assert.equal(body.items[0].item_name, "Milk");
});

test("a new listing can specify its storage type", async () => {
  const { status, body } = await api("/api/donations", {
    method: "POST",
    body: JSON.stringify({
      donorId: 2, itemName: "Frozen Peas", quantity: 2, unit: "bags",
      category: "Frozen", expiryDate: "2099-01-01", storageType: "Frozen",
      pickupLocation: "Block A, Kathmandu", contactMethod: "WhatsApp: +977-91XXXXXXXX",
    }),
  });
  assert.equal(status, 201);
  assert.equal(body.donation.storage_type, "Frozen");

  const list = await api("/api/donations?storageType=Frozen");
  assert.ok(list.body.items.some((d) => d.item_name === "Frozen Peas"));
});

// ---------- Add Item to Inventory (Plan Weekly Meals page) ----------

test("a user can add a new item to their inventory", async () => {
  const { status, body } = await api("/api/inventory", {
    method: "POST",
    body: JSON.stringify({
      userId: 1, itemName: "Broccoli", quantity: 2, unit: "heads",
      category: "Vegetable", expiryDate: "2099-01-01",
    }),
  });
  assert.equal(status, 201);
  assert.equal(body.item.item_name, "Broccoli");
  assert.equal(body.item.reserved_quantity, 0);

  const list = await api("/api/inventory?userId=1");
  assert.ok(list.body.items.some((i) => i.item_name === "Broccoli"));
});

test("adding an inventory item without required fields is rejected", async () => {
  const { status, body } = await api("/api/inventory", {
    method: "POST",
    body: JSON.stringify({ userId: 1, itemName: "Mystery Veg" }),
  });
  assert.equal(status, 422);
  assert.match(body.error, /required/i);
});

test("a newly added inventory item can complete a recipe match", async () => {
  // Beef Stir Fry needs Beef + Broccoli, neither of which are seeded, so it
  // shouldn't be suggested yet.
  const before = await api("/api/recipes/suggestions?userId=1");
  assert.ok(!before.body.recipes.some((r) => r.name === "Beef Stir Fry"));

  await api("/api/inventory", {
    method: "POST",
    body: JSON.stringify({ userId: 1, itemName: "Beef", quantity: 1, unit: "kg", category: "Meat", expiryDate: "2099-01-01" }),
  });
  await api("/api/inventory", {
    method: "POST",
    body: JSON.stringify({ userId: 1, itemName: "Broccoli", quantity: 1, unit: "heads", category: "Vegetable", expiryDate: "2099-01-01" }),
  });

  const after = await api("/api/recipes/suggestions?userId=1");
  assert.ok(after.body.recipes.some((r) => r.name === "Beef Stir Fry"));
});

// ---------- Login ----------

test("GET /api/users lists the seeded accounts for the login screen", async () => {
  const { status, body } = await api("/api/users");
  assert.equal(status, 200);
  assert.ok(body.users.some((u) => u.full_name.includes("Alice")));
});

test("POST /api/login succeeds with the correct password and fails for an unknown account", async () => {
  const good = await api("/api/login", { method: "POST", body: JSON.stringify({ userId: 2, password: "test1234" }) });
  assert.equal(good.status, 200);
  assert.match(good.body.user.full_name, /Alice/);
  assert.equal(good.body.user.password, undefined); // password must never be sent back

  const bad = await api("/api/login", { method: "POST", body: JSON.stringify({ userId: 999, password: "test1234" }) });
  assert.equal(bad.status, 400);
});

test("POST /api/login rejects a missing or incorrect password", async () => {
  const noPassword = await api("/api/login", { method: "POST", body: JSON.stringify({ userId: 2 }) });
  assert.equal(noPassword.status, 400);
  assert.match(noPassword.body.error, /password/i);

  const wrongPassword = await api("/api/login", { method: "POST", body: JSON.stringify({ userId: 2, password: "wrong" }) });
  assert.equal(wrongPassword.status, 401);
  assert.match(wrongPassword.body.error, /incorrect password/i);
});

test("GET /api/users never leaks passwords", async () => {
  const { body } = await api("/api/users");
  assert.ok(body.users.every((u) => u.password === undefined));
});

test("login returns a session token that can resume a session, and logout invalidates it", async () => {
  const login = await api("/api/login", { method: "POST", body: JSON.stringify({ userId: 2, password: "test1234" }) });
  assert.equal(login.status, 200);
  assert.ok(login.body.token && login.body.token.length > 10);

  // the token resumes the session without needing the password again
  const resumed = await api(`/api/session?token=${login.body.token}`);
  assert.equal(resumed.status, 200);
  assert.match(resumed.body.user.full_name, /Alice/);

  // logging out invalidates the token
  const out = await api("/api/logout", { method: "POST", body: JSON.stringify({ token: login.body.token }) });
  assert.equal(out.status, 200);

  const afterLogout = await api(`/api/session?token=${login.body.token}`);
  assert.equal(afterLogout.status, 401);
});

test("an unknown or missing session token fails to resume", async () => {
  const missing = await api("/api/session");
  assert.equal(missing.status, 401);

  const bogus = await api("/api/session?token=not-a-real-token");
  assert.equal(bogus.status, 401);
});

// ---------- Notifications ----------

test("claimer receives a notification with pickup details once the donor confirms", async () => {
  const claimRes = await api("/api/donations/1/claim", { method: "POST", body: JSON.stringify({ claimerId: 1 }) });
  const claimId = claimRes.body.claim.id;
  await api(`/api/claims/${claimId}/confirm`, { method: "PUT" });

  const { status, body } = await api("/api/notifications?userId=1");
  assert.equal(status, 200);
  assert.equal(body.unreadCount, 1);
  assert.match(body.notifications[0].message, /confirmed/i);
  assert.match(body.notifications[0].message, /Pickup/i);
  assert.match(body.notifications[0].message, /Block A, Kathmandu/);
});

test("PUT /api/notifications/read-all marks a user's notifications as read", async () => {
  const claimRes = await api("/api/donations/1/claim", { method: "POST", body: JSON.stringify({ claimerId: 1 }) });
  await api(`/api/claims/${claimRes.body.claim.id}/confirm`, { method: "PUT" });

  const before = await api("/api/notifications?userId=1");
  assert.equal(before.body.unreadCount, 1);

  const marked = await api("/api/notifications/read-all", { method: "PUT", body: JSON.stringify({ userId: 1 }) });
  assert.equal(marked.status, 200);

  const after = await api("/api/notifications?userId=1");
  assert.equal(after.body.unreadCount, 0);
  assert.ok(after.body.notifications.every((n) => n.is_read));
});
