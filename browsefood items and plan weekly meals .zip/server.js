/**
 * FreshGuard - Iteration 1 prototype
 * UC3 - Browse Food Items | UC6 - Plan Weekly Meals
 * Shraddha Sedhai (E2400153) - BIT216 Assignment 2, Iteration 1, Task 1
 *
 * Run: npm install && npm start   -> http://localhost:3000
 *
 * Each route below is annotated with the TC ID(s) from
 * Assignment2_Iteration1_Task1_ShraddhaSedhai.docx / Testing_Template.xlsx
 * that exercise it, so the report and the code trace to each other.
 */

const express = require("express");
const path = require("path");
const crypto = require("crypto");
const db = require("./data");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// ============================================================
// Login & Notifications
// ============================================================

// GET /api/users -> list of demo accounts for the login screen
// (password is stripped out - the dropdown should never expose credentials)
app.get("/api/users", (req, res) => {
  const safeUsers = db.users.map(({ password, ...u }) => u);
  res.json({ users: safeUsers });
});

// POST /api/login -> logs in as one of the seeded demo accounts, now
// checking a password as well as the chosen identity. Also issues a
// short-lived session token so the page can stay logged in across a
// refresh WITHOUT the browser ever having to store the password.
app.post("/api/login", (req, res) => {
  const userId = Number(req.body.userId);
  const password = req.body.password;
  const user = db.users.find((u) => u.id === userId);

  if (!user) {
    return res.status(400).json({ error: "Please choose an account to log in as." });
  }
  if (!password) {
    return res.status(400).json({ error: "Please enter your password." });
  }
  if (password !== user.password) {
    return res.status(401).json({ error: "Incorrect password." });
  }

  const token = crypto.randomBytes(24).toString("hex");
  db.sessions[token] = user.id;

  const { password: _pw, ...safeUser } = user; // never send the password back
  res.json({ user: safeUser, token });
});

// GET /api/session?token= -> resume a session after a page refresh.
// If the token isn't recognised (expired server restart, tampered value,
// or none at all) this fails closed and the person just logs in again.
app.get("/api/session", (req, res) => {
  const token = req.query.token;
  const userId = token && db.sessions[token];
  const user = userId && db.users.find((u) => u.id === userId);

  if (!user) {
    return res.status(401).json({ error: "Session expired. Please log in again." });
  }

  const { password: _pw, ...safeUser } = user;
  res.json({ user: safeUser });
});

// POST /api/logout -> invalidate a session token
app.post("/api/logout", (req, res) => {
  delete db.sessions[req.body.token];
  res.json({ message: "Logged out." });
});

// GET /api/notifications?userId= -> a user's notifications (newest first),
// e.g. "Your claim is confirmed. Pickup: ..." for the claimer, or
// "Your listing has a new claim request." for the donor.
app.get("/api/notifications", (req, res) => {
  const userId = Number(req.query.userId) || 1;
  const items = db.notifications
    .filter((n) => n.user_id === userId)
    .sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
  res.json({ notifications: items, unreadCount: items.filter((n) => !n.is_read).length });
});

// PUT /api/notifications/read-all -> mark a user's notifications as read
// (called when they open the notification panel)
app.put("/api/notifications/read-all", (req, res) => {
  const userId = Number(req.body.userId) || 1;
  db.notifications.forEach((n) => {
    if (n.user_id === userId) n.is_read = true;
  });
  res.json({ message: "Notifications marked as read." });
});

// ============================================================
// UC3 - Browse Food Items
// ============================================================

// GET /api/donations  -> TC01 (list all), TC02 (category filter), TC03 (no-match filter)
app.get("/api/donations", (req, res) => {
  const { location, category, expiryDate, storageType, search } = req.query;

  let results = db.donations.filter((d) => d.status === "active");

  if (category) {
    results = results.filter(
      (d) => d.category.toLowerCase() === String(category).toLowerCase()
    );
  }
  if (location) {
    results = results.filter((d) =>
      d.pickup_location.toLowerCase().includes(String(location).toLowerCase())
    );
  }
  if (storageType) {
    results = results.filter(
      (d) => (d.storage_type || "").toLowerCase() === String(storageType).toLowerCase()
    );
  }
  if (expiryDate) {
    results = results.filter((d) => d.expiry_date <= expiryDate);
  }
  if (search) {
    const q = String(search).toLowerCase();
    results = results.filter(
      (d) =>
        d.item_name.toLowerCase().includes(q) ||
        d.category.toLowerCase().includes(q) ||
        (d.availability_info || "").toLowerCase().includes(q)
    );
  }

  // TC03: filter combination matches nothing -> empty-state message, not an error
  if (results.length === 0) {
    return res.json({ items: [], message: "No donations match your filters." });
  }

  res.json({ items: results });
});

// POST /api/donations -> add a new donation listing (Browse Food Items "Add Item")
app.post("/api/donations", (req, res) => {
  const { donorId, itemName, quantity, unit, category, expiryDate, pickupLocation, contactMethod, availabilityInfo, storageType } = req.body;

  if (!itemName || !quantity || !unit || !category || !expiryDate || !pickupLocation || !contactMethod) {
    return res.status(422).json({
      error: "Item name, quantity, unit, category, expiry date, pickup location, and contact method are all required.",
    });
  }
  if (!(Number(quantity) > 0)) {
    return res.status(422).json({ error: "Quantity must be greater than 0." });
  }

  const donation = {
    id: db.nextId.donation++,
    donor_id: Number(donorId) || 1,
    item_name: String(itemName).trim(),
    quantity: Number(quantity),
    unit: String(unit).trim(),
    category: String(category).trim(),
    expiry_date: expiryDate,
    pickup_location: String(pickupLocation).trim(),
    contact_method: String(contactMethod).trim(),
    availability_info: availabilityInfo ? String(availabilityInfo).trim() : "",
    storage_type: storageType ? String(storageType).trim() : "Room Temperature",
    status: "active",
  };
  db.donations.push(donation);

  res.status(201).json({ donation, message: "Your donation listing has been posted." });
});

// GET /api/donations/:id -> TC04 (view full details)
app.get("/api/donations/:id", (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) {
    return res.status(400).json({ error: "Invalid donation id." });
  }
  const donation = db.donations.find((d) => d.id === id);
  if (!donation) {
    return res.status(404).json({ error: "Donation listing not found." });
  }
  res.json(donation);
});

// GET /api/my-donations?donorId= -> donor's own listings (any status) with any claims
// against them, so a donor can see and confirm pending claims (supports TC06 in the UI).
app.get("/api/my-donations", (req, res) => {
  const donorId = Number(req.query.donorId) || 1;
  const listings = db.donations
    .filter((d) => d.donor_id === donorId)
    .map((d) => ({
      ...d,
      claims: db.donationClaims
        .filter((c) => c.donation_id === d.id)
        .map((c) => ({
          ...c,
          claimer_name: db.users.find((u) => u.id === c.claimer_id)?.full_name || `User #${c.claimer_id}`,
        })),
    }));
  res.json({ listings });
});

// POST /api/donations/:id/claim -> TC05 (claim active listing), TC07 (block already-claimed)
app.post("/api/donations/:id/claim", (req, res) => {
  const { claimerId } = req.body;
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) {
    return res.status(400).json({ error: "Invalid donation id." });
  }
  const donation = db.donations.find((d) => d.id === id);

  if (!donation) {
    return res.status(404).json({ error: "Donation listing not found." });
  }

  // TC07: reject claim on a listing that is already claimed
  if (donation.status !== "active") {
    return res.status(409).json({ error: "This item has already been claimed." });
  }

  // A donor shouldn't be able to claim their own listing.
  if ((claimerId || 1) === donation.donor_id) {
    return res.status(400).json({ error: "You can't claim your own donation." });
  }

  const claim = {
    id: db.nextId.claim++,
    donation_id: donation.id,
    claimer_id: claimerId || 1,
    status: "pending",
    claimed_at: new Date().toISOString(),
  };
  db.donationClaims.push(claim);

  // Notify the donor (matches "donor is notified" in the acceptance criteria)
  db.notifications.push({
    id: db.nextId.notification++,
    user_id: donation.donor_id,
    type: "claim",
    message: `Your listing "${donation.item_name}" has a new claim request.`,
    is_read: false,
    created_at: new Date().toISOString(),
  });

  res.status(201).json({ claim, message: "Claim request submitted." });
});

// PUT /api/claims/:id/confirm -> TC06 (donor confirms a pending claim)
app.put("/api/claims/:id/confirm", (req, res) => {
  const claim = db.donationClaims.find((c) => c.id === Number(req.params.id));
  if (!claim) return res.status(404).json({ error: "Claim not found." });
  if (claim.status === "confirmed") {
    return res.status(409).json({ error: "This claim has already been confirmed." });
  }

  claim.status = "confirmed";
  const donation = db.donations.find((d) => d.id === claim.donation_id);
  donation.status = "claimed";

  // Notify the claimer with pickup details
  db.notifications.push({
    id: db.nextId.notification++,
    user_id: claim.claimer_id,
    type: "claim",
    message: `Your claim for "${donation.item_name}" is confirmed. Pickup: ${donation.pickup_location}, ${donation.contact_method}.`,
    is_read: false,
    created_at: new Date().toISOString(),
  });

  res.json({ claim, donation, message: "Claim confirmed and claimer notified." });
});

// ============================================================
// UC6 - Plan Weekly Meals
// ============================================================

// GET /api/inventory -> TC08 (inventory list for the meal planner page)
app.get("/api/inventory", (req, res) => {
  const userId = Number(req.query.userId) || 1;
  const items = db.inventoryItems.filter((i) => i.user_id === userId && i.status === "active");
  res.json({ items });
});

// POST /api/inventory -> add a new item to the logged-in user's own inventory.
// Used by the "+ Add Item" button on the Plan Weekly Meals page, so a user
// isn't limited to whatever inventory was seeded - they can add real items,
// which then also become available to the meal planner and recipe matcher.
app.post("/api/inventory", (req, res) => {
  const { userId, itemName, quantity, unit, category, expiryDate } = req.body;

  if (!itemName || !quantity || !unit || !category || !expiryDate) {
    return res.status(422).json({
      error: "Item name, quantity, unit, category, and expiry date are all required.",
    });
  }
  if (!(Number(quantity) > 0)) {
    return res.status(422).json({ error: "Quantity must be greater than 0." });
  }

  const item = {
    id: db.nextId.inventoryItem++,
    user_id: Number(userId) || 1,
    item_name: String(itemName).trim(),
    quantity: Number(quantity),
    unit: String(unit).trim(),
    expiry_date: expiryDate,
    category: String(category).trim(),
    status: "active",
    reserved_quantity: 0,
  };
  db.inventoryItems.push(item);

  res.status(201).json({ item, message: "Item added to your inventory." });
});

// GET /api/meal-plans -> TC08 (weekly calendar grid)
app.get("/api/meal-plans", (req, res) => {
  const userId = Number(req.query.userId) || 1;
  const plans = db.mealPlans
    .filter((p) => p.user_id === userId)
    .map((p) => ({
      ...p,
      items: db.mealPlanItems
        .filter((mi) => mi.meal_plan_id === p.id)
        .map((mi) => ({
          ...mi,
          item_name: db.inventoryItems.find((i) => i.id === mi.inventory_item_id)?.item_name,
        })),
    }));
  res.json({ plans });
});

// POST /api/meal-plans -> TC09 (add a meal), TC10 (validation error on missing fields)
app.post("/api/meal-plans", (req, res) => {
  const { userId, mealDate, mealSlot, description, items } = req.body;

  // TC10: day/slot or inventory items missing -> validation error, nothing saved
  if (!mealDate || !mealSlot || !Array.isArray(items) || items.length === 0) {
    return res.status(422).json({
      error: "A day, a meal slot, and at least one inventory item are required.",
    });
  }

  // Resolve every requested item against inventory and validate stock
  // BEFORE writing anything, so a bad entry can't leave a half-saved plan.
  const resolved = [];
  for (const entry of items) {
    const invItem = db.inventoryItems.find(
      (i) => i.id === entry.inventoryItemId || i.item_name === entry.itemName
    );
    if (!invItem) {
      return res.status(422).json({ error: `Inventory item "${entry.itemName || entry.inventoryItemId}" was not found.` });
    }
    const reserveQty = entry.quantity == null ? 1 : Number(entry.quantity);
    if (!(reserveQty > 0)) {
      return res.status(422).json({ error: `Quantity for "${invItem.item_name}" must be greater than 0.` });
    }
    const available = invItem.quantity - (invItem.reserved_quantity || 0);
    if (reserveQty > available) {
      return res.status(422).json({
        error: `Not enough "${invItem.item_name}" in stock (only ${available}${invItem.unit} available).`,
      });
    }
    resolved.push({ invItem, reserveQty });
  }

  const plan = {
    id: db.nextId.mealPlan++,
    user_id: userId || 1,
    meal_date: mealDate,
    meal_slot: mealSlot,
    description: description || resolved.map((r) => r.invItem.item_name).join(" + "),
    created_at: new Date().toISOString(),
  };
  db.mealPlans.push(plan);

  const savedItems = [];
  for (const { invItem, reserveQty } of resolved) {
    invItem.reserved_quantity = (invItem.reserved_quantity || 0) + reserveQty;

    const mealPlanItem = {
      id: db.nextId.mealPlanItem++,
      meal_plan_id: plan.id,
      inventory_item_id: invItem.id,
      reserved_quantity: reserveQty,
    };
    db.mealPlanItems.push(mealPlanItem);
    savedItems.push({ ...mealPlanItem, item_name: invItem.item_name });
  }

  res.status(201).json({ plan, items: savedItems });
});

// DELETE /api/meal-plans/:id -> remove a planned meal and release its
// reserved inventory back to "available" (was previously not possible at all).
app.delete("/api/meal-plans/:id", (req, res) => {
  const id = Number(req.params.id);
  const plan = db.mealPlans.find((p) => p.id === id);
  if (!plan) return res.status(404).json({ error: "Meal plan entry not found." });

  const relatedItems = db.mealPlanItems.filter((mi) => mi.meal_plan_id === id);
  for (const mi of relatedItems) {
    const invItem = db.inventoryItems.find((i) => i.id === mi.inventory_item_id);
    if (invItem) {
      invItem.reserved_quantity = Math.max(0, (invItem.reserved_quantity || 0) - mi.reserved_quantity);
    }
  }

  for (let i = db.mealPlanItems.length - 1; i >= 0; i--) {
    if (db.mealPlanItems[i].meal_plan_id === id) db.mealPlanItems.splice(i, 1);
  }
  const planIdx = db.mealPlans.findIndex((p) => p.id === id);
  if (planIdx !== -1) db.mealPlans.splice(planIdx, 1);

  res.json({ message: "Meal removed and reserved inventory released." });
});

// GET /api/recipes/suggestions -> TC11 (match), TC13 (no match), TC14 (prioritise expiry)
app.get("/api/recipes/suggestions", (req, res) => {
  const userId = Number(req.query.userId) || 1;

  // `onlyItemNames` lets the demo/test harness simulate a smaller inventory
  // (used to reproduce TC13's "insufficient inventory" scenario) without
  // mutating the shared in-memory data.
  let inventoryNames = db.inventoryItems
    .filter((i) => i.user_id === userId && i.status === "active")
    .map((i) => i.item_name);

  if (req.query.onlyItemNames) {
    const allow = String(req.query.onlyItemNames).split(",");
    inventoryNames = inventoryNames.filter((n) => allow.includes(n));
  }

  const inventoryByName = {};
  db.inventoryItems.forEach((i) => (inventoryByName[i.item_name] = i));

  const matches = db.recipes
    .filter((r) => r.ingredients.every((ing) => inventoryNames.includes(ing)))
    .map((r) => {
      // Rank by the soonest expiry date among the recipe's ingredients,
      // so recipes that use up soon-to-expire stock are suggested first.
      const soonestExpiry = r.ingredients
        .map((ing) => inventoryByName[ing]?.expiry_date)
        .filter(Boolean)
        .sort()[0];
      return { ...r, soonestExpiry };
    })
    .sort((a, b) => (a.soonestExpiry > b.soonestExpiry ? 1 : -1));

  // TC13: no recipes match the available inventory
  if (matches.length === 0) {
    return res.json({ recipes: [], message: "No matching recipes found. Add more to inventory." });
  }

  res.json({ recipes: matches });
});

// POST /api/meal-plans/from-recipe -> TC12 (add a suggested recipe straight to the plan)
app.post("/api/meal-plans/from-recipe", (req, res) => {
  const { userId, recipeName, mealDate, mealSlot } = req.body;
  const recipe = db.recipes.find((r) => r.name === recipeName);
  if (!recipe) return res.status(404).json({ error: "Recipe not found." });
  if (!mealDate || !mealSlot) {
    return res.status(422).json({ error: "A day and a meal slot are required." });
  }

  const plan = {
    id: db.nextId.mealPlan++,
    user_id: userId || 1,
    meal_date: mealDate,
    meal_slot: mealSlot,
    description: recipeName,
    created_at: new Date().toISOString(),
  };
  db.mealPlans.push(plan);

  const savedItems = [];
  for (const name of recipe.ingredients) {
    const invItem = db.inventoryItems.find((i) => i.item_name === name && i.user_id === (userId || 1));
    if (!invItem) continue;
    invItem.reserved_quantity = (invItem.reserved_quantity || 0) + 1;
    const mealPlanItem = {
      id: db.nextId.mealPlanItem++,
      meal_plan_id: plan.id,
      inventory_item_id: invItem.id,
      reserved_quantity: 1,
    };
    db.mealPlanItems.push(mealPlanItem);
    savedItems.push({ mealPlanItemId: mealPlanItem.id, item_name: invItem.item_name, reserved_quantity: 1 });
  }

  res.status(201).json({ plan, items: savedItems, message: recipeName + " added to your plan; ingredients reserved." });
});

// Malformed JSON in a request body should come back as a clean 400,
// not crash the server or fall through as an unhandled 500.
app.use((err, req, res, next) => {
  if (err.type === "entity.parse.failed") {
    return res.status(400).json({ error: "Request body must be valid JSON." });
  }
  console.error(err);
  res.status(500).json({ error: "Something went wrong on the server." });
});

// Only start listening when this file is run directly (npm start).
// When required by the automated test suite, we just export `app` and
// let the tests spin up their own ephemeral listener.
if (require.main === module) {
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log(`FreshGuard Iteration 1 prototype running on http://localhost:${PORT}`));
}

module.exports = app;
