# FreshGuard — Iteration 1 Prototype (UC3 & UC6)

Working prototype for **Epic 1 – Browse Food Items** and **Epic 2 – Plan Weekly Meals**,
covering both user stories in each epic (browse/filter/claim donations, and
plan meals from inventory with recipe suggestions).

## How to run it

You need [Node.js](https://nodejs.org) installed (v18+).

```bash
cd freshguard
npm install
npm start
```

Then open **http://localhost:3000** in your browser and log in as one of the seeded
accounts (Shraddha, Alice, Bob, or Carol — no password needed, this is a prototype).
Three tabs:
- **Browse Food Items** — filter/search donation listings (category, location, storage
  type, expiry date), click a card for full details, and click "Request Donation" to claim.
- **My Listings (Donor)** — shows *your own* donation listings (log in as Alice, Bob, or
  Carol to see the seeded ones) and lets you confirm pending claims.
- **Plan Weekly Meals** — see your inventory, add meals to the weekly calendar (or
  remove one with the × on its chip), get recipe suggestions.

The 🔔 bell in the top bar shows your notifications — e.g. a donor gets notified
when someone requests their item, and a claimer gets notified with **pickup details**
once the donor confirms.

Data lives in memory (`data.js`) and resets every time you restart the server —
that's normal for an Iteration 1 prototype.

## What's implemented, mapped to the user stories

**Epic 1 – Browse Food Items**
- *US1 (browse & filter):* log in → Browse Food Items shows all active listings;
  filters for location, category, expiry date, and **storage type** (Room
  Temperature / Refrigerated / Frozen) narrow the list live; opening an item shows
  name, quantity, expiry date, pickup location, and contact method.
- *US2 (claim a donation):* "Request Donation" logs a claim; the listing shows as
  "claimed" once confirmed; the donor sees a claim request against their listing and
  can confirm it; the claimer then gets a notification containing the pickup details.

**Epic 2 – Plan Weekly Meals**
- *US1 (weekly plan from inventory):* the Plan Weekly Meals page shows a 7-day
  calendar plus current inventory; adding a meal to a day/slot reserves the
  selected inventory items, and reserved amounts show against each item.
- *US2 (recipe suggestions):* the page suggests recipes matched against your
  current inventory, prioritising items closer to expiry, and shows
  "No matching recipes found. Add more to inventory." when nothing matches.

## Login & identity

Login is intentionally simple (pick an account, no password) since this is a
functional prototype, not a security exercise. Whichever account you log in as
drives claiming, posting donations, "My Listings", and meal planning — there's no
separate "viewing as" switcher anymore, since Epic 1 US1's acceptance criteria
start from "If I log in…".

## Automated tests

```bash
npm test
```

`test/api.test.js` uses Node's built-in test runner (no extra dependencies) and
exercises the full API against the real running server: the original 14 documented
test cases (TC01–TC14), plus tests for the storage-type filter, login, and the
notification-with-pickup-details flow.

## File guide

| File | Purpose |
|---|---|
| `server.js` | Express API |
| `data.js` | In-memory seed data (donations, inventory, users, notifications, recipes) |
| `public/` | Frontend — login screen, Browse/My Listings/Plan Weekly Meals tabs, notification bell |

## Test case → code mapping

| TC | What it checks | Endpoint |
|---|---|---|
| TC01 | View all active listings | `GET /api/donations` |
| TC02 | Category filter | `GET /api/donations?category=Dairy` |
| TC03 | No-match filter → empty state | `GET /api/donations?category=Frozen&location=Unknown Area` |
| TC04 | View listing detail | `GET /api/donations/:id` |
| TC05 | Claim an active listing | `POST /api/donations/:id/claim` |
| TC06 | Donor confirms claim → claimer notified with pickup details | `PUT /api/claims/:id/confirm` |
| TC07 | Block claiming an already-claimed listing | `POST /api/donations/:id/claim` → 409 |
| TC08 | Calendar + inventory load | `GET /api/inventory`, `GET /api/meal-plans` |
| TC09 | Add a meal, reserve inventory | `POST /api/meal-plans` |
| TC10 | Validation error on missing day/slot/items | `POST /api/meal-plans` → 422 |
| TC11 | Recipe suggestions match inventory | `GET /api/recipes/suggestions` |
| TC12 | Add a suggested recipe to the plan | `POST /api/meal-plans/from-recipe` |
| TC13 | No matching recipes → message | `GET /api/recipes/suggestions` |
| TC14 | Suggestions prioritise soon-to-expire items | `GET /api/recipes/suggestions` (sorted by soonest ingredient expiry) |
| — | Storage type filter | `GET /api/donations?storageType=Refrigerated` |
| — | Log in as a seeded account | `POST /api/login`, `GET /api/users` |
| — | View / clear notifications | `GET /api/notifications`, `PUT /api/notifications/read-all` |
| — | Add a new donation listing (with storage type) | `POST /api/donations` |
| — | Search listings by name/category/notes | `GET /api/donations?search=` |

## Before you submit
- [x] Working prototype covering both epics' user stories — this app
- [x] Automated test suite covering all documented + new test cases
- [ ] Git collaboration — push this code to your team's repo so there's commit history to show
- [ ] Project progress — pair with your Gantt chart / WBS status

