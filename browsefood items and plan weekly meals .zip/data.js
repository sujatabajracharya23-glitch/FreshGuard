/**
 * In-memory "database" for the Iteration 1 prototype.
 * Field names follow the Data Dictionary (Assignment 1, Section B.7):
 * inventory_items, donations, donation_claims, meal_plans, meal_plan_items, notifications.
 *
 * Seed values are deliberately chosen to match the Test Data used in
 * Assignment2_Iteration1_Task1 (TC01-TC14) so the documented test cases
 * can be reproduced exactly against this code.
 */

let nextId = { donation: 1, claim: 1, mealPlan: 1, mealPlanItem: 1, notification: 1, inventoryItem: 7 };

// token -> userId. Lets a refreshed page resume its session without the
// browser ever having to store the person's password.
const sessions = {};

// Users referenced by the demo (id 1 = the logged-in user, "you")
// Every demo account shares the same password so graders/testers can log in
// as anyone without needing a list of separate credentials. In a real system
// this would be a per-user bcrypt hash, not a plain-text shared value.
const DEMO_PASSWORD = "test1234";
const users = [
  { id: 1, full_name: "Shraddha Sedhai (you)", password: DEMO_PASSWORD },
  { id: 2, full_name: "Alice (donor)", password: DEMO_PASSWORD },
  { id: 3, full_name: "Bob (donor)", password: DEMO_PASSWORD },
  { id: 4, full_name: "Carol (donor)", password: DEMO_PASSWORD },
];

// ---- UC3: donations available to browse ----
// 3 active + 1 already-claimed listing, matching TC01 / TC07 test data.
const donations = [
  {
    id: nextId.donation++,
    donor_id: 2,
    item_name: "Apples (Fuji)",
    quantity: 6,
    unit: "pieces",
    category: "Fruit",
    expiry_date: addDays(5),
    pickup_location: "Block A, Kathmandu",
    contact_method: "WhatsApp: +977-98XXXXXXXX",
    availability_info: "Available after 5pm",
    storage_type: "Room Temperature",
    status: "active", // used by TC05
  },
  {
    id: nextId.donation++,
    donor_id: 2,
    item_name: "White Bread",
    quantity: 2,
    unit: "loaves",
    category: "Bakery",
    expiry_date: addDays(2),
    pickup_location: "Block A, Kathmandu",
    contact_method: "WhatsApp: +977-98XXXXXXXX",
    availability_info: "Best picked up today",
    storage_type: "Room Temperature",
    status: "active", // used by TC04
  },
  {
    id: nextId.donation++,
    donor_id: 3,
    item_name: "Milk",
    quantity: 1,
    unit: "litre",
    category: "Dairy",
    expiry_date: addDays(3),
    pickup_location: "Block B, Kathmandu",
    contact_method: "WhatsApp: +977-97XXXXXXXX",
    availability_info: "Unopened carton",
    storage_type: "Refrigerated",
    status: "active", // used by TC02
  },
  {
    id: nextId.donation++,
    donor_id: 4,
    item_name: "Chicken Fillet",
    quantity: 1,
    unit: "kg",
    category: "Meat",
    expiry_date: addDays(1),
    pickup_location: "Block C, Kathmandu",
    contact_method: "WhatsApp: +977-96XXXXXXXX",
    availability_info: "Frozen, needs collection today",
    storage_type: "Frozen",
    status: "claimed", // used by TC07 (negative case)
  },
];

const donationClaims = [];

// ---- UC6: the logged-in user's own inventory used for meal planning ----
const inventoryItems = [
  { id: 1, user_id: 1, item_name: "Chicken", quantity: 500, unit: "g", expiry_date: addDays(4), category: "Meat", status: "active", reserved_quantity: 0 },
  { id: 2, user_id: 1, item_name: "Rice", quantity: 1000, unit: "g", expiry_date: addDays(30), category: "Grain", status: "active", reserved_quantity: 0 },
  { id: 3, user_id: 1, item_name: "Eggs", quantity: 12, unit: "pieces", expiry_date: addDays(10), category: "Dairy", status: "active", reserved_quantity: 0 },
  { id: 4, user_id: 1, item_name: "Onion", quantity: 3, unit: "pieces", expiry_date: addDays(14), category: "Vegetable", status: "active", reserved_quantity: 0 },
  { id: 5, user_id: 1, item_name: "Spinach", quantity: 1, unit: "bunch", expiry_date: addDays(1), category: "Vegetable", status: "active", reserved_quantity: 0 }, // used by TC14 (expires soon)
  { id: 6, user_id: 1, item_name: "Pasta", quantity: 500, unit: "g", expiry_date: addDays(60), category: "Grain", status: "active", reserved_quantity: 0 },
];

const mealPlans = [];
const mealPlanItems = [];
const notifications = [];

// ---- Recipe reference data used by GET /api/recipes/suggestions ----
const recipes = [
  { name: "Egg Fried Rice", ingredients: ["Rice", "Eggs", "Onion"] },     // TC11
  { name: "Veggie Pasta", ingredients: ["Pasta", "Spinach"] },            // TC14 (uses soon-to-expire Spinach)
  { name: "Chicken Rice Bowl", ingredients: ["Chicken", "Rice", "Onion"] },
  { name: "Beef Stir Fry", ingredients: ["Beef", "Broccoli"] },           // deliberately unmatched
];

function addDays(n) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

function resetData() {
  // Re-seed everything to its Iteration-1 starting state. Used between
  // automated test runs so each test file starts from the documented
  // Test Data instead of leaking state from a previous run.
  nextId.donation = 1; nextId.claim = 1; nextId.mealPlan = 1;
  nextId.mealPlanItem = 1; nextId.notification = 1; nextId.inventoryItem = 7;

  donations.length = 0;
  donations.push(
    { id: nextId.donation++, donor_id: 2, item_name: "Apples (Fuji)", quantity: 6, unit: "pieces", category: "Fruit", expiry_date: addDays(5), pickup_location: "Block A, Kathmandu", contact_method: "WhatsApp: +977-98XXXXXXXX", availability_info: "Available after 5pm", storage_type: "Room Temperature", status: "active" },
    { id: nextId.donation++, donor_id: 2, item_name: "White Bread", quantity: 2, unit: "loaves", category: "Bakery", expiry_date: addDays(2), pickup_location: "Block A, Kathmandu", contact_method: "WhatsApp: +977-98XXXXXXXX", availability_info: "Best picked up today", storage_type: "Room Temperature", status: "active" },
    { id: nextId.donation++, donor_id: 3, item_name: "Milk", quantity: 1, unit: "litre", category: "Dairy", expiry_date: addDays(3), pickup_location: "Block B, Kathmandu", contact_method: "WhatsApp: +977-97XXXXXXXX", availability_info: "Unopened carton", storage_type: "Refrigerated", status: "active" },
    { id: nextId.donation++, donor_id: 4, item_name: "Chicken Fillet", quantity: 1, unit: "kg", category: "Meat", expiry_date: addDays(1), pickup_location: "Block C, Kathmandu", contact_method: "WhatsApp: +977-96XXXXXXXX", availability_info: "Frozen, needs collection today", storage_type: "Frozen", status: "claimed" }
  );

  donationClaims.length = 0;

  inventoryItems.length = 0;
  inventoryItems.push(
    { id: 1, user_id: 1, item_name: "Chicken", quantity: 500, unit: "g", expiry_date: addDays(4), category: "Meat", status: "active", reserved_quantity: 0 },
    { id: 2, user_id: 1, item_name: "Rice", quantity: 1000, unit: "g", expiry_date: addDays(30), category: "Grain", status: "active", reserved_quantity: 0 },
    { id: 3, user_id: 1, item_name: "Eggs", quantity: 12, unit: "pieces", expiry_date: addDays(10), category: "Dairy", status: "active", reserved_quantity: 0 },
    { id: 4, user_id: 1, item_name: "Onion", quantity: 3, unit: "pieces", expiry_date: addDays(14), category: "Vegetable", status: "active", reserved_quantity: 0 },
    { id: 5, user_id: 1, item_name: "Spinach", quantity: 1, unit: "bunch", expiry_date: addDays(1), category: "Vegetable", status: "active", reserved_quantity: 0 },
    { id: 6, user_id: 1, item_name: "Pasta", quantity: 500, unit: "g", expiry_date: addDays(60), category: "Grain", status: "active", reserved_quantity: 0 }
  );

  mealPlans.length = 0;
  mealPlanItems.length = 0;
  notifications.length = 0;
  for (const key in sessions) delete sessions[key];
}

module.exports = {
  nextId, users, donations, donationClaims,
  inventoryItems, mealPlans, mealPlanItems, notifications, recipes,
  sessions, resetData,
};
